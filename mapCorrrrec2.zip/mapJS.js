﻿	var map;
	
	var stopJeu=false;
	var point=10; //Si la réponse est bonne
	var perte=8; //Si la réponse est fausse
	
	var score=0; //Score de départ
	
	//Ajoute les points au score
	function ajouterPoint(){
		score=score+point;
	}
	
	function malus(){
		score=score-perte;
	}
	
	//alert(typeof score);
	
	var compteur = 20; //Début du compte à rebours
	var intervalId = null;
	
	var finished="Terminé ! ";
	
	function jouer(){
		jeu.style.display="block";
		annuler.style.display="block";
	}
	
	function annulerJouer(){
		jeu.style.display="none";
		stopJeu=true;
	}
	
	//Débute le compte à rebours
	function start(){
		answers.style.display="block";
		intervalId = setInterval(bip, 1000); //Aide à modifier le temps toutes les 1000 millisecondes
		setTimeout(action, compteur * 1000);
		
		//Rend possible les indices
		$( "#drapFrance" ).draggable({ revert: "valid"});
		$( "#drapCanada" ).draggable({ revert: "valid" });
		$( "#drapMali" ).draggable({ revert: "valid" });	
		$( "#drapItalie" ).draggable({ revert: "valid" });
		$( "#drapBelgique" ).draggable({ revert: "valid" });
		$( "#drapJapon" ).draggable({ revert: "valid" });
		$( "#drapAllemagne" ).draggable({ revert: "valid" });
		$( "#drapBolivie" ).draggable({ revert: "valid" });

	}
	
	//Découle et affiche le compte à rebours
	function bip(){
		if(compteur <= 1) {
			pluriel = "";
			if(compteur <= 0) {
				compteur=0;
			}
        } else {
			pluriel = "s";
        }
		document.getElementById("bip").innerHTML = "Il vous reste "+compteur + " seconde"+pluriel+" restante"+pluriel;
		
		if (Boolean(stopJeu)==false){
			compteur--;
		} else {
			compteur = 0;//Arrête le décompte si le jeu est arrêté
		}
	}
	
	//Termine le jeu
	function action(){
		clearInterval(intervalId);
		alert("C'est terminé !");
		if (score<=0){
			score=0;
		}
		document.getElementById("bip").innerHTML = finished + " Votre score : " +score;	
	}
	
	/*function verifReponse(drapeau){
		var IdPays = ui.draggable.attr("id");
			
			var chaine="";
			chaine+="Pays : "+IdPays+"</br>";
			
			$( "#draggable" ).html(chaine);
			if ("drap"+IdPays==drapeau){
				$("#"+drapeau)
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				
				ajouterPoint();				
			
			} else {
				$("#"+drapeau)
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				malus();
			}
	}*/
	
	
	window.onload = function () {
	
	//Chargement initial de la MAP
	map = L.map('map').setView([0,0],4);
        L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {attribution: 'PING', maxZoom: 4}).addTo(map);
	
	
	/*$( "#drapFrance" ).draggable( { drag: function( event, ui ) {
		//score=score-demi
		//malus();
		}});*/
	
	
	$( "#drapFrance" ).droppable({
      drop: function( event, ui ) {
			//verifReponse(drapFrance);
			
			var IdPays = ui.draggable.attr("id");
			
			var chaine="";
			chaine+="Pays : "+IdPays+"</br>";
			
			$( "#draggable" ).html(chaine);
			if ("drap"+IdPays=="drapFrance"){
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				
				ajouterPoint();				
			
			} else {
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				malus();
			}
			
				
      }
    });
	
	
	$( "#drapCanada" ).droppable({
      drop: function( event, ui ) {
			//verifReponse(drapFrance);
			
			var IdPays = ui.draggable.attr("id");
			
			var chaine="";
			chaine+="Pays : "+IdPays+"</br>";
			
			$( "#draggable" ).html(chaine);
			if ("drap"+IdPays=="drapCanada"){
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				
				ajouterPoint();				
			
			} else {
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				malus();
			}
			
				
      }
    });
	

	$( "#drapMali" ).droppable({
      drop: function( event, ui ) {
			//verifReponse(drapFrance);
			
			var IdPays = ui.draggable.attr("id");
			
			var chaine="";
			chaine+="Pays : "+IdPays+"</br>";
			
			$( "#draggable" ).html(chaine);
			if ("drap"+IdPays=="drapMali"){
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				
				ajouterPoint();				
			
			} else {
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				malus();
			}
			
				
      }
    });
	
	$( "#drapItalie" ).droppable({
      drop: function( event, ui ) {
			//verifReponse(drapItalie);
			
			var IdPays = ui.draggable.attr("id");
			
			var chaine="";
			chaine+="Pays : "+IdPays+"</br>";
			
			$( "#draggable" ).html(chaine);
			if ("drap"+IdPays=="drapItalie"){
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				
				ajouterPoint();				
			
			} else {
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				malus();
			}
			
				
      }
    });
	
	$( "#drapBelgique" ).droppable({
      drop: function( event, ui ) {
			//verifReponse(drapFrance);
			
			var IdPays = ui.draggable.attr("id");
			
			var chaine="";
			chaine+="Pays : "+IdPays+"</br>";
			
			$( "#draggable" ).html(chaine);
			if ("drap"+IdPays=="drapBelgique"){
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				
				ajouterPoint();				
			
			} else {
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				malus();
			}
			
				
      }
    });
	
	$( "#drapJapon" ).droppable({
      drop: function( event, ui ) {
			//verifReponse(drapFrance);
			
			var IdPays = ui.draggable.attr("id");
			
			var chaine="";
			chaine+="Pays : "+IdPays+"</br>";
			
			$( "#draggable" ).html(chaine);
			if ("drap"+IdPays=="drapJapon"){
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				
				ajouterPoint();				
			
			} else {
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				malus();
			}
			
				
      }
    });
	
	$( "#drapAllemagne" ).droppable({
      drop: function( event, ui ) {
			//verifReponse(drapFrance);
			
			var IdPays = ui.draggable.attr("id");
			
			var chaine="";
			chaine+="Pays : "+IdPays+"</br>";
			
			$( "#draggable" ).html(chaine);
			if ("drap"+IdPays=="drapAllemagne"){
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				
				ajouterPoint();				
			
			} else {
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				malus();
			}
			
				
      }
    });
	
	$( "#drapBolivie" ).droppable({
      drop: function( event, ui ) {
			//verifReponse(drapFrance);
			
			var IdPays = ui.draggable.attr("id");
			
			var chaine="";
			chaine+="Pays : "+IdPays+"</br>";
			
			$( "#draggable" ).html(chaine);
			if ("drap"+IdPays=="drapBolivie"){
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				
				ajouterPoint();				
			
			} else {
				$( this )
					//.addClass( "ui-state-highlight" )
					.find( "p" )
					.append(IdPays + "</br>");
				malus();
			}
			
				
      }
    });

	
	
	//Rendre draggable les div des pays
	$( "#France" ).draggable({ revert: "valid" });
	$( "#Canada" ).draggable({ revert: "valid" });
	$( "#Italie" ).draggable({ revert: "valid" });
	$( "#Belgique" ).draggable({ revert: "valid" });
	$( "#Japon" ).draggable({ revert: "valid" });
	$( "#Espagne" ).draggable({ revert: "valid" });
	$( "#Mali" ).draggable({ revert: "valid" });
	$( "#Malte" ).draggable({ revert: "valid" });
	$( "#Maroc" ).draggable({ revert: "valid" });
	$( "#Bolivie" ).draggable({ revert: "valid" });
	
	
	
	/*$("#dragable").draggable({
		drag: function(event, ui){
			$( this ).addClass("ui-state-highlight").find( "p" ).html( "Héhé" );
		}
	});



  $(function() {
    $( "#draggable" ).draggable({ revert: "valid" });
    $( "#droppable" ).droppable({
      drop: function( event, ui ) {
        $( this )
          .addClass( "ui-state-highlight" )
          //.find( "p" )
            //.html( "Dropped!" );
			
			
      }
    });
  });*/
  
	
	
	//Rendre la map droppable
	 $( "#map" ).droppable({
		 
		 //Evenement lors du drop
		drop: function( event, ui ) {
			
			//Recupère l'id du block div "dropped" dans la map
			
			
			var country = ui.draggable.attr("id");
			
			var IdPays = country.substring(4);
			
			
			var chaine="";
			chaine+="Pays : "+IdPays+"</br>";
			
			//Requete AJAX pour récupérer les coordonnées (lati, longi) du pays
			$.ajax({
			    type: 'GET',
			    url: "http://nominatim.openstreetmap.org/search",
			    dataType: 'jsonp',
			    jsonpCallback: 'data',
			    data: { format: "json", limit: 1,country: IdPays,json_callback: 'data' },
			    error: function(xhr, status, error) {
				alert("ERROR "+error);
			    },
			    success: function(data){
				//récupérer les coordonnées (lati, longi) du pays dans les données json provenant du serveur
				var lati = '';
				var longi = '';
				$.each(data, function() {
					lati = this['lat'] ;
					longi = this['lon'] ;
				});
				
				//affichage des infos
				chaine+="Latitude : "+lati+"</br>";
				chaine+="Longitute : "+longi+"</br>";
				$( "#info" ).html(chaine);
				
				//MAJ de la map à la position (lati, longi) du pays
				map.panTo(new L.LatLng(lati, longi));		
				
			    }
			});
			
			
		}
	});
	
	//Sur le click de la map, ajout d'un marqueur sur la carte avec le nom du pays
	map.on('click', onClick);
	
	function onClick(e) {
		//recherche le pays sur lequel on a clické
		//Requete AJAX pour récupérer les infos du pays sur le point où on a cliqué (lati, longi) 
		$.ajax({
		    type: 'GET',
		    url: "http://nominatim.openstreetmap.org/reverse",
		    dataType: 'jsonp',
		    jsonpCallback: 'data',
		    data: { format: "json", limit: 1,lat: e.latlng.lat,lon: e.latlng.lng,json_callback: 'data' },
		    error: function(xhr, status, error) {
			alert("ERROR "+error);
		    },
		    success: function(data){
			//récupérer les coordonnées (lati, longi) du pays dans les données json provenant du serveur
			var paysVisite="";
			$.each(data, function() {
				paysVisite = this['country'] ;
			});
			
			//affichage des infos
			L.marker(e.latlng).addTo(map).bindPopup("Lat, Lon : " + e.latlng.lat + ", " + e.latlng.lng+" Pays : "+paysVisite).openPopup();
			L.circle(e.latlng, 1).addTo(map);			
		    }
		});
	}
	
	
}



